# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = 'f636bb8cfd795a17354af20917ad29a7c710e1ec4e13c363e741d2e3c51144ba446c3aa67684e0f500fbf6eb1dc93a3e8cc4d505b2afc5c9b11db8a4635b6d89'